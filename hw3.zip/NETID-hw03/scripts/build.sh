#!/bin/bash -ex

docker build -tag hw03:latest .
